﻿#include<quazip/JlCompress.h>

int main(int argc, char* argv[])
{
	JlCompress::compressFile("", "");

	return 0;
}