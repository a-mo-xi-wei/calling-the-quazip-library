﻿#include<quazip/JlCompress.h>

void test_compressFile()
{
	//压缩单个文件
	if (!JlCompress::compressFile("tmp/1.zip", "tmp/one.txt")) {
		qInfo() << "compressFile tmp/one.txt failed";
	}
	//单个文件解压(把1.zip中的one.txt单独解压出来，放到one_.txt文件中去)
	auto file = JlCompress::extractFile("tmp/1.zip", "one.txt", "tmp/one_.txt");
	if (file.isEmpty()) {
		qInfo() << "extractFile tmp/one_.txt failed";
	}


}

//压缩多个文件
void test_compressFiles()
{
	//压缩多个文件
	if (!JlCompress::compressFiles("tmp/files.zip", {"tmp/one.txt","tmp/two.txt","tmp/test_quazip.exe"})) {
		qInfo() << "compressFiles files.zip failed";
	}
	//解压zip到指定的目录中
	auto file_list = JlCompress::extractDir("tmp/files.zip", "tmp/files");
	if (file_list.isEmpty()) {
		qInfo() << "extractDir failed";
	}
	else {
		qInfo() << file_list;
	}
}

//压缩文件夹(目录)
void test_compressDir()
{
	//压缩整个文件夹
	if (!JlCompress::compressDir("tmp/files_.zip", "tmp/files")) {
		qInfo() << "compressDir fialed";
	}

	//解压
	auto file_list = JlCompress::extractDir("tmp/files_.zip", "tmp/files_");
	if (file_list.isEmpty()) {
		qInfo() << "extractDir failed";
	}
	else {
		qInfo() << file_list;
	}

}

//获取压缩包文件列表
void test_getFileList()
{
	QStringList file_list =  JlCompress::getFileList("tmp/files_.zip");
	if (file_list.isEmpty()) {
		qInfo() << "is emptry";
	}
	else {
		for (auto& file : file_list) {
			qInfo() << file;
		}
	}
}
int main(int argc, char* argv[])
{
	test_getFileList();
	return 0;
}